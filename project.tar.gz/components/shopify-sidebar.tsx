"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Skeleton } from "./ui/skeleton"
import { Button } from "./ui/button"
import {
  User, Package, DollarSign, Calendar, MapPin,
  CheckCircle2, XCircle, AlertCircle, Loader2, ExternalLink, X
} from "lucide-react"
import { Alert, AlertDescription } from "./ui/alert"

interface ShopifySidebarProps {
  customerEmail: string
  shopDomain?: string
  onClose?: () => void
}

export default function ShopifySidebar({ customerEmail, shopDomain, onClose }: ShopifySidebarProps) {
  const [loading, setLoading] = useState(true)
  const [customer, setCustomer] = useState<any>(null)
  const [orders, setOrders] = useState<any[]>([])
  const [totalSpent, setTotalSpent] = useState(0)
  const [currency, setCurrency] = useState('USD')
  const [error, setError] = useState<string | null>(null)
  const [isConfigured, setIsConfigured] = useState(false)

  // Extract email from "Name <email@example.com>" format
  const extractedEmail = (() => {
    if (!customerEmail) return ''
    const match = customerEmail.match(/<(.+?)>/)
    return match ? match[1] : customerEmail
  })()

  useEffect(() => {
    if (!extractedEmail) return

    // Check if Shopify is configured
    fetch('/api/shopify/config')
      .then(res => res.json())
      .then(data => {
        if (data.config && data.config.isConfigured) {
          setIsConfigured(true)
          fetchCustomerData()
        } else {
          setLoading(false)
          setIsConfigured(false)
        }
      })
      .catch(err => {
        console.error('Error checking Shopify config:', err)
        setLoading(false)
        setIsConfigured(false)
      })
  }, [extractedEmail])

  const fetchCustomerData = async () => {
    try {
      setLoading(true)
      setError(null)

      const response = await fetch(`/api/shopify/customer?email=${encodeURIComponent(extractedEmail)}`)

      if (!response.ok) {
        if (response.status === 404) {
          // Check if it's a config error or customer not found
          const errorData = await response.json()
          if (errorData.error && errorData.error.includes('not configured')) {
            setError('Client info not available')
            setIsConfigured(false)
          } else {
            // Customer exists but not found in Shopify
            setError('No client data found')
          }
          return
        }
        throw new Error('Failed to fetch customer data')
      }

      const data = await response.json()
      setCustomer(data.customer)
      setOrders(data.recentOrders || [])
      setTotalSpent(data.totalSpent || 0)

      // Use currency from API response
      if (data.currency) {
        console.log('[Shopify] Detected currency:', data.currency)
        setCurrency(data.currency)
      } else {
        console.log('[Shopify] No currency in response, using default USD')
      }
    } catch (err) {
      console.error('Error fetching Shopify customer data:', err)
      setError(err instanceof Error ? err.message : 'Failed to load customer data')
    } finally {
      setLoading(false)
    }
  }

  const formatCurrency = (amount: string | number, currency: string = 'USD') => {
    const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount
    const currencySymbols: { [key: string]: string } = {
      USD: '$',
      EUR: '€',
      GBP: '£',
      JPY: '¥',
      CAD: '$',
      AUD: '$',
      PKR: 'Rs',
      INR: '₹',
      CNY: '¥',
    }
    const symbol = currencySymbols[currency] || currency
    return `${symbol}${numAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
  }

  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString)
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      })
    } catch {
      return dateString
    }
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'paid':
      case 'fulfilled':
        return 'text-green-600 dark:text-green-400'
      case 'pending':
      case 'unfulfilled':
        return 'text-yellow-600 dark:text-yellow-400'
      case 'refunded':
      case 'cancelled':
        return 'text-red-600 dark:text-red-400'
      default:
        return 'text-muted-foreground'
    }
  }

  return (
    <div className="flex flex-col h-full w-full bg-card border-l border-border/50 overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-border/50 bg-card/50 backdrop-blur-sm flex-shrink-0">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-semibold">Client Info</h2>
          </div>
          {onClose && (
            <Button
              size="sm"
              variant="ghost"
              onClick={onClose}
              className="h-8 w-8 p-0 transition-all duration-300 ease-out hover:scale-110 hover:bg-muted hover:shadow-sm"
              title="Close Client Info"
            >
              <X className="w-4 h-4 transition-transform duration-300 hover:rotate-90" />
            </Button>
          )}
        </div>
        {shopDomain && (
          <p className="text-xs text-muted-foreground">{shopDomain}</p>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {error ? (
          <div className="text-sm text-muted-foreground text-center py-8">
            <AlertCircle className="w-12 h-12 mx-auto mb-4 text-destructive/50" />
            <p className="text-destructive">{error}</p>
            <Button
              variant="outline"
              size="sm"
              onClick={fetchCustomerData}
              className="mt-4"
            >
              Retry
            </Button>
          </div>
        ) : !isConfigured ? (
          <div className="text-sm text-muted-foreground text-center py-8">
            <User className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
            <p>Client info not available</p>
            <p className="text-xs mt-2">Integration or data not available for this contact</p>
          </div>
        ) : loading ? (
          <div className="space-y-3">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        ) : !customer && orders.length === 0 ? (
          <div className="text-sm text-muted-foreground text-center py-8">
            <User className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
            <p>No client data found</p>
            <p className="text-xs mt-2">This email is not associated with any recorded data</p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Customer Summary */}
            {customer && (
              <Card>
                <CardContent className="p-4 space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <div className="text-xs text-muted-foreground">Total Spent</div>
                      <div className="text-lg font-semibold">
                        {formatCurrency(customer.totalSpent.toString(), currency)}
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-xs text-muted-foreground">Orders</div>
                      <div className="text-lg font-semibold flex items-center gap-1">
                        <Package className="h-4 w-4" />
                        {customer.ordersCount}
                      </div>
                    </div>
                  </div>

                  {customer.firstName || customer.lastName ? (
                    <div className="text-sm">
                      <span className="font-medium">
                        {customer.firstName} {customer.lastName}
                      </span>
                    </div>
                  ) : null}

                  {customer.phone && (
                    <div className="text-sm text-muted-foreground">
                      📞 {customer.phone}
                    </div>
                  )}

                  {customer.verifiedEmail ? (
                    <div className="flex items-center gap-1 text-xs text-green-600 dark:text-green-400">
                      <CheckCircle2 className="h-3 w-3" />
                      Verified email
                    </div>
                  ) : (
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <AlertCircle className="h-3 w-3" />
                      Unverified email
                    </div>
                  )}

                  {customer.addresses && customer.addresses.length > 0 && (
                    <div className="space-y-1">
                      <div className="text-xs text-muted-foreground flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        Address
                      </div>
                      {customer.addresses
                        .filter(addr => addr.isDefault)
                        .map(addr => (
                          <div key={addr.id} className="text-xs">
                            {addr.address1}
                            {addr.address2 && `, ${addr.address2}`}
                            <br />
                            {addr.city}, {addr.province} {addr.zip}
                            <br />
                            {addr.country}
                          </div>
                        ))}
                    </div>
                  )}

                  {customer.tags && customer.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {customer.tags.map((tag: string, idx: number) => (
                        <span
                          key={idx}
                          className="text-xs px-2 py-0.5 bg-muted rounded-md"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Recent Orders */}
            {orders.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">Recent Orders ({orders.length})</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {orders.slice(0, 5).map((order) => (
                    <div
                      key={order.id}
                      className="p-3 bg-muted/50 rounded-md text-xs space-y-2 border border-border/50 hover:border-border transition-colors"
                    >
                      {/* Order header with number and total */}
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-sm">{order.name}</span>
                        <span className="font-bold text-base">
                          {formatCurrency(
                            order.totalPriceSet?.shopMoney?.amount || order.totalPrice || '0',
                            currency
                          )}
                        </span>
                      </div>

                      {/* Order metadata */}
                      <div className="flex items-center gap-2 text-muted-foreground flex-wrap">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {formatDate(order.createdAt)}
                        </span>
                        {order.financialStatus && (
                          <>
                            <span>•</span>
                            <span className={`capitalize font-medium ${getStatusColor(order.financialStatus)}`}>
                              {order.financialStatus}
                            </span>
                          </>
                        )}
                        {order.fulfillmentStatus && (
                          <>
                            <span>•</span>
                            <span className={`capitalize font-medium ${getStatusColor(order.fulfillmentStatus)}`}>
                              {order.fulfillmentStatus}
                            </span>
                          </>
                        )}
                      </div>

                      {/* Line items */}
                      {order.lineItems && order.lineItems.length > 0 && (
                        <div className="bg-muted/50 rounded p-2 space-y-1 border-l-2 border-primary/30">
                          {order.lineItems.slice(0, 3).map((item: any, idx: number) => (
                            <div key={idx} className="text-muted-foreground text-xs">
                              <span className="font-medium">{item.quantity}x</span> {item.title}
                              {item.sku && <span className="text-muted-foreground/70"> (SKU: {item.sku})</span>}
                            </div>
                          ))}
                          {order.lineItems.length > 3 && (
                            <div className="text-muted-foreground/70 italic">
                              +{order.lineItems.length - 3} more items
                            </div>
                          )}
                        </div>
                      )}

                      {/* Order note if present */}
                      {order.note && (
                        <div className="text-xs text-muted-foreground italic border-l-2 border-amber-500/30 pl-2">
                          "{order.note}"
                        </div>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* View in Shopify Link */}
            {customer && shopDomain && (
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => {
                  window.open(
                    `https://${shopDomain}/admin/customers/${customer.id}`,
                    '_blank'
                  )
                }}
              >
                <ExternalLink className="h-3 w-3 mr-2" />
                View in CRM
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  )
}





